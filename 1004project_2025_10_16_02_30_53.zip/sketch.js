

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255);
  noFill(0);
  for(let i =0; i<width; i=i+40)
    {
     for(let j=0;j<height; j=j+40)
       {
         rect(i,j,20,20);
       }
    }
  fill(0,0,0);
  for(let k=30; k<width; k=k+40)
    {
      for(let m=30; m<height; m=m+40)
        {
          ellipse(k,m,10,10);
        }
    }
  
}